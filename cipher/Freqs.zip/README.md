# ngram-freqs

You have been provided with four files:

 - `1gram-freqs`
 - `2gram-freqs`
 - `3gram-freqs`
 - `4gram-freqs`

An `ngram` is a sequence of alphabetic (i.e. `A` to `Z`) characters of length
`n`.  Each file above encodes the frequencies (number of occurrences) of all
ngrams of their given length in the Google Books Corpus (of English Language
books).  These data-sets are useful for cryptanalysis, specifically frequency
analysis.

## Encoding

The files follow a simple binary encoding format:  Each file is a sequence of
64-bit (8 byte) little endian unsigned integers, laid out one after the other,
in the dictionary order of the ngram they correspond to.

## Example

To help verify decoding logic for ngram files, here is a textual representation
of `1gram-freqs`, and excerpts from `2gram-freqs`:

### `1gram-freqs`

```
A: 286527429118
B: 52905544693
C: 119155568598
D: 136017528785
E: 445155370175
F: 85635440629
G: 66615316232
H: 180074687596
I: 269731642485
J: 5657910830
K: 19261229433
L: 144998552911
M: 89506734085
N: 257770795264
O: 272276534337
P: 76112599849
Q: 4292916949
R: 223767519675
S: 232082812755
T: 330535289102
U: 97273082907
V: 37532682260
W: 59712390260
X: 8369138754
Y: 59331661972
Z: 3205398166
```

### `2gram-freqs` Excerpts

```
AA: 79794787
BA: 4122472992
CA: 15174413181
DA: 4259590348
EA: 19403941063
FA: 4624241031
GA: 4175274057
HA: 26103411208
IA: 8072199471
JA: 729206855
KA: 478095427
LA: 14874551789
MA: 15938689768
NA: 9790855551
OA: 1620913259
PA: 9123652775
QA: 4298294
RA: 19332539912
SA: 6147356936
TA: 14941000711
UA: 3844138094
VA: 3946966167
WA: 10865206430
XA: 834649781
YA: 444542870
ZA: 702199296
```

## Source

These files are derived from English Letter Frequency Counts: Mayzner Revisited
[0], by Peter Norvig.  The data in that article is itself derived from the
Google Books Ngram Corpus [1] which is licensed under the Creative Commons
Attribution 3.0 Unported License [2].

[0]: https://norvig.com/mayzner.html
[1]: http://storage.googleapis.com/books/ngrams/books/datasetsv2.html
[2]: https://creativecommons.org/licenses/by/3.0/
